# Full Stack App - Render Deployment

## Deploy on Render
1. Push this repo to GitHub.
2. Create new **Web Service** in Render.
3. Connect your repo.
4. In Render settings:
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
5. Add environment variable:
   - `MONGO_URI=your_mongo_connection_string`
6. Deploy 🚀
